globalThis.PWM_BUILD_INFO = Object.freeze({
  browser: "firefox",
  mode: "enterprise",
  enterprise: true,
  target: "firefox-enterprise",
  builtAt: "2026-05-10T20:56:26.025Z"
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = globalThis.PWM_BUILD_INFO;
}
