globalThis.PWM_BUILD_INFO = Object.freeze({
  browser: "chrome",
  mode: "consumer",
  enterprise: false,
  target: "chrome",
  builtAt: "2026-05-17T16:54:25.127Z"
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = globalThis.PWM_BUILD_INFO;
}
