globalThis.PWM_BUILD_INFO = Object.freeze({
  browser: "firefox",
  mode: "consumer",
  enterprise: false,
  target: "firefox",
  builtAt: "2026-05-17T16:54:25.391Z"
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = globalThis.PWM_BUILD_INFO;
}
