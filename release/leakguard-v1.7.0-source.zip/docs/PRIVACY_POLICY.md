# LeakGuard Privacy Policy

Last updated: 2026-05-05

## Summary

LeakGuard processes protected prompt text and explicitly selected local text files locally in your browser to help reduce accidental leaks of secrets, email addresses, and public IPv4 network details.

LeakGuard does not operate a backend service and does not send your prompt text, selected file contents, raw secrets, email addresses, or raw network values to our servers. LeakGuard does not use telemetry, cloud processing, or remote model calls.

## What LeakGuard Accesses

LeakGuard may access text you type, paste, or submit in protected site composers so it can:

- detect likely secrets
- detect likely email addresses
- detect public IPv4 hosts and CIDR ranges
- show an allow-or-redact decision before send
- replace sensitive values with placeholders
- reveal placeholders later only inside extension-owned UI

LeakGuard may also access a local text file only after you choose it in the File Scanner page or paste, drop, or select it through a protected AI composer. This release supports text-based files only and can export a redacted text copy or a sanitized JSON findings report from the File Scanner page.

LeakGuard scans and redacts supported text files locally. Unsupported formats such as PDFs, DOCX files, images, archives, executables, and binary files are not scanned, redacted, or protected in this release. LeakGuard warns before these unsupported files continue through the normal site upload flow.

For protected AI composers, larger supported text files may be redacted with streaming/chunked local processing before LeakGuard hands off a sanitized in-memory file to the site. This avoids sending raw text-file content through protected upload paths while keeping processing local to your browser.

## What LeakGuard Stores

LeakGuard stores only the following extension data:

- normalized user-managed protected-site rules in extension `storage.local`
- session-scoped placeholder mappings and reveal state in `chrome.storage.session`

LeakGuard does not intentionally persist raw prompts, selected file contents, raw secrets, or raw public IPv4 values in long-term extension storage. File Scanner scan results stay in memory on the scanner page until you clear the scan or close the page. Protected composer file redaction uses in-memory text, chunks, and sanitized `File`/`Blob` objects only as needed for local redaction and handoff.

## What LeakGuard Does Not Send

LeakGuard does not send the following to our servers because the extension does not use a backend service:

- prompt text
- selected file contents
- raw secret values
- email addresses
- raw network values
- placeholder maps
- browsing telemetry
- streaming redaction chunks

LeakGuard also suppresses common documentation placeholders, example values, and development variable names where possible to reduce false positives during local scanning.

Sanitized File Scanner JSON reports do not include raw secret values by default. Redacted file copies and reports are created only after you click the export buttons.

## Site Permissions

LeakGuard includes built-in protection for supported AI/chat sites and can request optional site access when you explicitly add another protected site.

LeakGuard does not request optional access for every site unless you choose to protect that site.

Enterprise deployments may override those defaults through managed policy, including disabling user-added protected sites.

## Secure Reveal

When you reveal a placeholder, the raw value is shown only inside extension-owned UI. LeakGuard does not write the revealed raw value back into the website DOM for that reveal flow.

Enterprise deployments may disable secure reveal by policy.

## Extension Page Hardening

LeakGuard extension pages use a restrictive Content Security Policy for extension-owned UI contexts. That policy allows packaged scripts only and disables plugin objects, base URL overrides, and third-party framing of extension pages.

## Limitations

LeakGuard is a risk-reduction tool, not a guarantee of secrecy or privacy, and it may miss or misclassify some sensitive text. It does not protect against:

- browser compromise or malware
- OS-level clipboard/history capture
- screenshots or shoulder surfing
- unsupported binary document, archive, executable, or image redaction flows such as PDF, DOCX, ZIP, EXE, screenshots, or image OCR
- websites or editors whose DOM changes break interception logic
- raw values that you intentionally reveal or manually send

PDF, DOCX, image, archive, executable, and binary-file redaction are not enabled in this release. The current file protection paths redact supported text-based files only. Unsupported files are not marked as scanned, protected, or sanitized. Supported text files above the current local streaming limit are blocked rather than uploaded raw through protected text-file paths.

## Data Retention

Session-scoped placeholder mappings are kept in browser session storage and are cleared when the relevant session state is removed. User-managed protected-site rules remain until you remove or disable them.

## Contact

If you publish LeakGuard, replace this section with your actual support and privacy contact details before store submission.
