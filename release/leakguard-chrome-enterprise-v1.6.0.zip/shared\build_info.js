globalThis.PWM_BUILD_INFO = Object.freeze({
  browser: "chrome",
  mode: "enterprise",
  enterprise: true,
  target: "chrome-enterprise",
  builtAt: "2026-05-10T20:56:25.716Z"
});

if (typeof module !== "undefined" && module.exports) {
  module.exports = globalThis.PWM_BUILD_INFO;
}
